This zip file contains five datasets. 

synthetic-*.csv file description

First two columns are the feature values.
The final column is the class label.



Video_Game_Sales.csv contains sales information for various video games (although their names have not been included). The first eleven columns are feature values, the last column (Critic_Score) is the class label. Since this class label contains integer values, they will first need to be discretized into more reasonable labels. Some data is missing from this dataset. It is indicated by either a missing field or by 'N/A'.